import 'package:flutter/material.dart';

void main() {
  runApp(const SportsHubApp());
}

class SportsHubApp extends StatelessWidget {
  const SportsHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sports Hub',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080B0D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB7FF00),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    HomeTab(),
    LiveTab(),
    CalendarTab(),
    LeaguesTab(),
    MoreTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        backgroundColor: const Color(0xFF0E1215),
        indicatorColor: const Color(0xFFB7FF00),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.radio_outlined), selectedIcon: Icon(Icons.radio), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Calendar'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'Leagues'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('Sports Hub', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
            ),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        const Text('All fixtures. All results. All sports.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 24),
        const SectionTitle('LIVE NOW'),
        const MatchCard(
          live: true,
          league: 'Football',
          home: 'Orlando Pirates',
          away: 'Mamelodi Sundowns',
          homeScore: '1',
          awayScore: '0',
          time: "45+2'",
        ),
        const SizedBox(height: 22),
        const SectionTitle("TODAY'S FIXTURES"),
        const MatchCard(
          league: 'Premier League',
          home: 'Manchester United',
          away: 'Arsenal',
          time: '20:00',
        ),
        const MatchCard(
          league: 'NBA',
          home: 'Lakers',
          away: 'Boston Celtics',
          time: '02:30',
        ),
        const MatchCard(
          league: 'Rugby',
          home: 'Springboks',
          away: 'Australia',
          time: '17:00',
        ),
      ],
    );
  }
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimplePage(
      title: 'Live Scores',
      subtitle: 'Follow matches as they happen.',
      child: MatchCard(
        live: true,
        league: 'Football',
        home: 'Orlando Pirates',
        away: 'Mamelodi Sundowns',
        homeScore: '1',
        awayScore: '0',
        time: "45+2'",
      ),
    );
  }
}

class CalendarTab extends StatelessWidget {
  const CalendarTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimplePage(
      title: 'Calendar',
      subtitle: 'Fixtures and results by date.',
      child: Column(
        children: [
          MatchCard(league: 'Football', home: 'Real Madrid', away: 'Bayern Munich', time: '21:00'),
          MatchCard(league: 'Tennis', home: 'Player A', away: 'Player B', time: '18:30'),
        ],
      ),
    );
  }
}

class LeaguesTab extends StatelessWidget {
  const LeaguesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimplePage(
      title: 'Leagues',
      subtitle: 'Football, basketball, rugby, tennis and more.',
      child: Column(
        children: [
          LeagueTile('Premier League'),
          LeagueTile('DStv Premiership'),
          LeagueTile('NBA'),
          LeagueTile('URC'),
          LeagueTile('ATP Tour'),
        ],
      ),
    );
  }
}

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimplePage(
      title: 'More',
      subtitle: 'Your Sports Hub settings.',
      child: Column(
        children: [
          ListTile(leading: Icon(Icons.favorite_border), title: Text('Favourite teams')),
          ListTile(leading: Icon(Icons.notifications_none), title: Text('Notifications')),
          ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings')),
        ],
      ),
    );
  }
}

class SimplePage extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;

  const SimplePage({super.key, required this.title, required this.subtitle, required this.child});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 22),
        child,
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(text, style: const TextStyle(color: Color(0xFFB7FF00), fontWeight: FontWeight.w800)),
    );
  }
}

class MatchCard extends StatelessWidget {
  final bool live;
  final String league;
  final String home;
  final String away;
  final String time;
  final String? homeScore;
  final String? awayScore;

  const MatchCard({
    super.key,
    this.live = false,
    required this.league,
    required this.home,
    required this.away,
    required this.time,
    this.homeScore,
    this.awayScore,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF11171A),
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: Text(league, style: const TextStyle(color: Colors.white54, fontSize: 12))),
                if (live) const Text('● LIVE', style: TextStyle(color: Color(0xFFB7FF00), fontSize: 12, fontWeight: FontWeight.bold)),
                if (!live) Text(time, style: const TextStyle(color: Colors.white70)),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(child: Text(home, style: const TextStyle(fontWeight: FontWeight.w700))),
                if (homeScore != null) Text(homeScore!, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('vs', style: TextStyle(color: Colors.white38))),
                if (awayScore != null) Text(awayScore!, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                Expanded(child: Text(away, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700))),
              ],
            ),
            if (live) ...[
              const SizedBox(height: 8),
              Align(alignment: Alignment.center, child: Text(time, style: const TextStyle(color: Color(0xFFB7FF00)))),
            ],
          ],
        ),
      ),
    );
  }
}

class LeagueTile extends StatelessWidget {
  final String name;
  const LeagueTile(this.name, {super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF11171A),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0xFFB7FF00),
          child: Icon(Icons.emoji_events, color: Colors.black),
        ),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
