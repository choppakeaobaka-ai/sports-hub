# Sports Hub

A Flutter starter app for Android and iOS.

## What is included
- Dark sports UI
- Home screen
- Live scores screen
- Calendar screen
- Leagues screen
- More/settings screen
- Sample fixtures and live result cards

## Run it
1. Install Flutter.
2. Extract this project.
3. Run `flutter pub get`.
4. Run `flutter run`.
5. For Android: `flutter build apk`.
6. For iOS: `flutter build ios` (requires macOS/Xcode).

## Next development stage
Connect a licensed sports-data API for real fixtures, results, standings and live scores. Then add user accounts, favourite teams and push notifications.
